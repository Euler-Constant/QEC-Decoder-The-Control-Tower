"""Run from a fresh environment after installing requirements.txt."""
import time
from pathlib import Path
import numpy as np,stim
from decoder import decode
elapsed=0.
for basis in 'XZ':
 circuit=stim.Circuit.from_file(str(Path(__file__).with_name(f'{basis}_circuit.stim')))
 d,o=circuit.compile_detector_sampler(seed=1).sample(100000,separate_observables=True)
 t=time.perf_counter(); y=decode(circuit,d); elapsed+=time.perf_counter()-t
 assert y.shape==o.shape and np.isin(y,[0,1]).all()
 print(basis,'LER',float(np.mean(y!=o)),flush=True)
print('Total decode seconds:',elapsed)
