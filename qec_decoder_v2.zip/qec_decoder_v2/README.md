# QEC decoder v2

The default `decode(circuit, detector_events)` produces the recommended accuracy-focused predictions. The original submission remains separate.

## What changed

1. Belief propagation can run for up to 60 iterations rather than 30.
2. Ordered-statistics search runs even when BP finds a detector-consistent answer. Consistency alone does not establish logical correctness.
3. The search considers 256 free-variable single changes and pair changes among the first 64 free variables (up to 2,273 candidates including the base). The previous implementation considered at most 53 candidates only after BP failed to converge.
4. Each unique candidate contributes its independent-mechanism probability to one of the 16 logical classes. Each output bit is selected using the total candidate weight supporting 0 versus 1. This is an approximation using a restricted candidate list, not an exact posterior over all errors. It matches the competition's bitwise loss more closely than choosing the most likely individual error pattern.
5. Candidate scores are updated from the changed free variables and pivot variables, avoiding a full cost recomputation for every candidate.

## The requested partial-correction pipeline

This is implemented in `predict(..., front_steps=6, threshold=4.6, max_fixed=4)`:

- Run six short BP iterations on the original shot.
- Propose up to four mechanisms with estimated log odds below -4.6. These are model confidence estimates, not calibrated guarantees.
- XOR their detector effects out of the observed syndrome and record their logical effects.
- Pin the proposed mechanisms, remove their columns from the residual repair equations, and run the stronger decoder on the remaining problem.
- Combine the tentative and residual corrections. Check their detector parity against the original observations. Fall back to unrestricted decoding if the hypothesis yields inconsistent equations or a failed parity check.

The verifier checks candidate consistency; it cannot detect every logical error and does not establish fault tolerance. The marginal output combines candidate weights per logical bit and need not equal a single candidate's full logical vector.

The partial-correction version was compared with an equally strong decoder without partial corrections. It did not beat that control on tuning. Therefore the recommended default keeps `front_steps=0`; the experiment remains available through `predict` and `frozen_configs.json`. This is not a CoDecoder-style complete-shot confidence router.

## Validation and reproducibility

Tuning used 3,000 newly simulated shots per basis, with Stim seeds `19031 + ord(basis)`. Settings were frozen before holdout. Independent holdout used 10,000 new shots per basis, seeds `88023 + ord(basis)`. Original and new decoders see identical shots within each comparison. See `EXPERIMENT_REPORT.md` and the JSON results.

No training CSV labels or test labels are used by the decoder. No trained weights or existing QEC decoder library is used. The circuit's DEM supplies H, L, and error priors.

## Run

Use Python 3.12 for the locally tested environment. The organisers specify Python 3.13, which has not been tested here.

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
NUMBA_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 .venv/bin/python check_math.py
NUMBA_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 .venv/bin/python make_submission.py --test /path/to/test.csv --output submission_v2_accuracy.csv
```

`make_submission.py` checks IDs, binary detector values, prediction shape, binary outputs, exact ID order, column order, and repeated decoding of a reordered subset. It records the CSV and decoder source SHA-256 values.

For finalist timing, `check_handin.py` samples 100,000 fresh shots per basis and measures the two decode calls. Numba compilation occurs during import. The decoder does not hard-code the organiser's thread count; it follows the Numba environment. Local measurements made under concurrent workloads are not a timing-machine benchmark. The five-minute finalist limit still needs checking on representative hardware.

To reproduce the research comparisons:

```bash
NUMBA_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 .venv/bin/python compare.py 3000 19031
NUMBA_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 .venv/bin/python extra_search.py
NUMBA_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 .venv/bin/python accuracy_search.py
NUMBA_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 .venv/bin/python holdout.py
```

The first command creates the sampled tuning arrays needed by the next two. Hand in `decoder.py`, `baseline_decoder.py`, `requirements.txt`, and any other required supporting files; the supplied circuits and validation scripts are included for reproduction. Do not include a virtual environment.

The supplied circuit files originate from the hackathon repository; its provided license is retained in UPSTREAM_LICENSE.
