# Accuracy experiment results

Independent held-out evaluation: 10,000 X and 10,000 Z shots. All methods receive the same observations. Settings were frozen after a separate 6,000-shot tuning experiment. No Kaggle submissions were made.

| Method | X LER | Z LER | Overall LER |
|---|---:|---:|---:|
| Original submission decoder | 5.7125% | 5.1825% | 5.4475% |
| Recommended v2: stronger search + bit marginals | 4.2325% | 3.8075% | 4.0200% |
| Requested partial-correction cascade + bit marginals | 4.2575% | 3.8075% | 4.0325% |

V2 reduces held-out bit errors by 26.20% relative to the original decoder. Its absolute improvement is 1.4275 percentage points; approximate paired 95% interval [1.2532, 1.6018] points, treating each shot as the independent unit.

The partial-correction version minus the strong control has an LER difference of +0.0125 percentage points; paired 95% interval [-0.0107, +0.0357] points. Positive means more errors with the front end. This implementation does not establish an accuracy benefit from partial correction. The recommended CSV therefore uses the strong control, with the requested cascade retained as a reproducible experiment.

The front end makes tentative model-based corrections. No detector inconsistency was observed in these held-out candidate checks; this is not proof of logical correctness or fault tolerance. The candidate-list marginal probabilities are approximate.

## Checks

- Small exact-enumeration problems verify minimum-cost decoding and probability sums over the full tiny candidate space.
- Residual syndrome and logical XOR bookkeeping verified.
- Reordered repeated calls are deterministic in local checks.
- Pinned requirements installed in a new Python 3.12 virtual environment; mathematical and functional checks passed there.
- Final CSV format, row count, IDs, binary values, and source hash checked.
- Fresh-environment predictions exactly matched the CSV on 512 test rows (256 per basis). The entire 200,000-row fresh-environment rerun was not performed.

## Runtime and limitations

Full test prediction generation took 627.9 s for X and 400.1 s for Z locally, with eight Numba threads and concurrent validation work during part of the run. These are not comparable to the organisers' timing machine. The accuracy-focused version is not certified against the five-minute finalist cap; Python 3.13 and the NVIDIA B200 environment remain untested.

CSV SHA-256: `5eb9182f7f7e6eddf54fd54929afd02e37ff9535a02a96272be3ea626c61774e`
Decoder source SHA-256: `08450a36d650f77cdaad959239747ea8c54dd4b234d0bf3deed1d973500df1c4`

See README.md for the algorithm, selected configuration, and reproduction commands.
