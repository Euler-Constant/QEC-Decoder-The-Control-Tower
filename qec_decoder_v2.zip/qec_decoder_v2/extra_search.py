import json,time
from pathlib import Path
import numpy as np,stim
from decoder import predict
root=Path(__file__).resolve().parent
out=[]
for basis in 'XZ':
 c=stim.Circuit.from_file(str(root/f'{basis}_circuit.stim'))
 saved=np.load(root/f'tune_{basis}_strong.npz')
 d,o,baseline=saved['events'],saved['truth'],saved['baseline']
 for name,cfg in [('wider',{'nfree':128,'npair':40}),('wider_cascade',{'nfree':128,'npair':40,'front_steps':6,'threshold':4.6})]:
  start=time.perf_counter(); y,st=predict(c,d,**cfg)
  for mode in [0,1]:
   wrong=(y[:,mode]!=o).sum(axis=1); delta=(baseline!=o).sum(axis=1)-wrong
   row={'basis':basis,'config':name,'mode':['map','marginal'][mode],'ler':float(wrong.mean()/4),'seconds':time.perf_counter()-start,'fixed_mean':float(st[:,0].mean()),'invalid_shots':int(st[:,2].sum()),'paired_improvement':float(delta.mean()/4),'paired_se':float(delta.std(ddof=1)/4/np.sqrt(len(d)))}
   out.append(row); print(json.dumps(row),flush=True)
  np.savez_compressed(root/f'tune_{basis}_{name}.npz',events=d,truth=o,predictions=y,stats=st,baseline=baseline)
 (root/'extra_search.json').write_text(json.dumps(out,indent=2))
