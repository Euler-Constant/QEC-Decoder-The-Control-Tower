# Team explanation: second accuracy candidate

Our job is to predict four logical error bits from 70 detector readings. The competition scores every bit separately. We are improving a classical decoder for supplied simulated data; we are not operating or directly measuring a quantum computer.

The first submission used belief propagation to infer likely errors, followed by a limited repair search when BP failed to explain all the detector readings.

The new candidate does a wider search even when BP finds a consistent explanation. Different hidden errors can produce the same detector readings but imply different logical flips, so consistency alone is insufficient. Instead of selecting the single best explanation, we accumulate probability weight across the searched explanations and predict each logical bit separately. The probability calculation is restricted to our candidate list and is approximate.

We also implemented our proposed partial-correction pipeline. A short first BP stage tentatively identifies a few confident error mechanisms. We remove their detector effects, solve the residual problem with the stronger decoder, combine the corrections, and check the original detector equations. This works within each shot. It does not use CoDecoder's complete-shot confidence-routing structure.

We compared all versions on exactly the same independent 20,000 simulated shots, separate from tuning:

| Decoder | Overall logical error rate |
|---|---:|
| Original submission decoder | 5.4475% |
| Stronger search with candidate-weighted bit predictions | 4.0200% |
| Partial-correction pipeline with the same stronger search | 4.0325% |

The recommended candidate makes about 26.2% fewer incorrect bit predictions than the original on this held-out set. The difference between the two new variants is too small to distinguish confidently in this experiment. We therefore have no demonstrated accuracy benefit from the extra front end, and recommend the simpler strong control for submission. The requested pipeline remains implemented and reproducible.

The earlier 5.32% baseline figure came from a different validation sample. The fair comparison here is 5.4475% versus 4.0200%, because both use identical held-out shots.

The final consistency check detects some invalid correction candidates. It cannot identify every wrong logical prediction and is not a guarantee of fault tolerance.

These are simulated validation results, not Kaggle scores. The new search is slower locally; finalist speed optimisation and verification on representative hardware remain necessary.
