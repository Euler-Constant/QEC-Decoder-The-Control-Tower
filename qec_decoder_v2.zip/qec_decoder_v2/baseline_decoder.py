"""Original sum-product belief propagation with ordered-statistics repair."""
import numpy as np
from numba import njit, prange


def problem(circuit):
    dem=circuit.detector_error_model()
    cols={}; ps=[]
    for ins in dem.flattened():
        if ins.type!='error': continue
        ds=set(); ls=set()
        for t in ins.targets_copy():
            if t.is_relative_detector_id(): ds.symmetric_difference_update([t.val])
            elif t.is_logical_observable_id(): ls.symmetric_difference_update([t.val])
        key=(tuple(sorted(ds)),tuple(sorted(ls))); p=ins.args_copy()[0]
        if key in cols:
            j=cols[key]; ps[j]=ps[j]*(1-p)+p*(1-ps[j])
        else: cols[key]=len(ps); ps.append(p)
    H=np.zeros((dem.num_detectors,len(ps)),np.uint8)
    L=np.zeros((dem.num_observables,len(ps)),np.uint8)
    for (ds,ls),j in cols.items():
        H[list(ds),j]=1; L[list(ls),j]=1
    rr,cc=np.nonzero(H); order=np.argsort(rr,kind='stable'); rr=rr[order]; cc=cc[order]
    ptr=np.r_[0,np.cumsum(np.bincount(rr,minlength=len(H)))]
    return H,L,np.log((1-np.array(ps))/np.array(ps)),cc,ptr

@njit(cache=True)
def repair(H,s,post,prior,hard):
    m,n=H.shape
    order=np.argsort(np.abs(post))
    A=H[:,order].copy(); b=s.copy()
    piv=np.empty(m,np.int64); rank=0
    for c in range(n):
        r=rank
        while r<m and A[r,c]==0: r+=1
        if r==m: continue
        if r!=rank:
            tmp=A[r].copy(); A[r]=A[rank]; A[rank]=tmp
            q=b[r]; b[r]=b[rank]; b[rank]=q
        for i in range(m):
            if i!=rank and A[i,c]:
                A[i]^=A[rank]; b[i]^=b[rank]
        piv[rank]=c; rank+=1
        if rank==m: break
    x=hard[order].copy()
    for i in range(rank): x[piv[i]]=0
    for i in range(rank):
        v=b[i]
        for j in range(n): v^=A[i,j]&x[j]
        x[piv[i]]=v
    best=x.copy(); cost=0.
    for j in range(n): cost+=prior[order[j]]*x[j]
    isp=np.zeros(n,np.uint8)
    for i in range(rank): isp[piv[i]]=1
    free=np.empty(24,np.int64); nf=0
    for j in range(n):
        if not isp[j]:
            free[nf]=j; nf+=1
            if nf==24: break
    # Test one and two deviations from the posterior hard decision.
    for a in range(nf):
        for bb in range(-1,min(a,8)):
            if bb>=0 and a>=8: continue
            y=x.copy(); j=free[a]; y[j]^=1
            for i in range(rank): y[piv[i]]^=A[i,j]
            if bb>=0:
                j=free[bb]; y[j]^=1
                for i in range(rank): y[piv[i]]^=A[i,j]
            val=0.
            for j in range(n): val+=prior[order[j]]*y[j]
            if val<cost: cost=val; best=y
    out=np.empty(n,np.uint8)
    for j in range(n): out[order[j]]=best[j]
    return out

@njit(parallel=True, cache=True)
def batch(events,H,L,prior,cols,ptr,iterations):
    shots=events.shape[0]; n=len(prior); ne=len(cols); m=len(ptr)-1
    result=np.zeros((shots,L.shape[0]),np.uint8)
    for shot in prange(shots):
        s=events[shot]; v=prior[cols].copy(); msg=np.zeros(ne); post=prior.copy(); hard=np.zeros(n,np.uint8)
        success=False
        for it in range(iterations):
            for r in range(m):
                start=ptr[r]; end=ptr[r+1]
                # Prefix/suffix products avoid division near zero.
                prefix=np.ones(end-start+1); suffix=1.
                for k in range(start,end): prefix[k-start+1]=prefix[k-start]*np.tanh(v[k]*.5)
                for k in range(end-1,start-1,-1):
                    prod=prefix[k-start]*suffix
                    if s[r]: prod=-prod
                    prod=max(-.999999999999,min(.999999999999,prod))
                    msg[k]=2*np.arctanh(prod)
                    suffix*=np.tanh(v[k]*.5)
            post=prior.copy()
            for k in range(ne): post[cols[k]]+=msg[k]
            for j in range(n): hard[j]=post[j]<0
            success=True
            for r in range(m):
                val=0
                for k in range(ptr[r],ptr[r+1]): val^=hard[cols[k]]
                if val!=s[r]: success=False; break
            if success: break
            for k in range(ne):
                new=max(-40.,min(40.,post[cols[k]]-msg[k]))
                v[k]=.8*new+.2*v[k]
        if not success: hard=repair(H,s,post,prior,hard)
        for o in range(L.shape[0]):
            val=0
            for j in range(n): val^=L[o,j]&hard[j]
            result[shot,o]=val
    return result

_CACHE={}
def decode(circuit,detector_events):
    key=str(circuit)
    if key not in _CACHE: _CACHE[key]=problem(circuit)
    H,L,p,c,ptr=_CACHE[key]
    events=np.asarray(detector_events,dtype=np.uint8)
    packed=np.packbits(events,axis=1)
    unique,inverse=np.unique(packed,axis=0,return_inverse=True)
    unique_events=np.unpackbits(unique,axis=1)[:,:H.shape[0]].copy()
    return batch(unique_events,H,L,p,c,ptr,30)[inverse]

# Compile numerical kernels during import, outside the timed decode calls.
batch(np.zeros((1,1),np.uint8),np.ones((1,1),np.uint8),np.zeros((4,1),np.uint8),np.ones(1),np.zeros(1,np.int64),np.array([0,1],np.int64),1)
