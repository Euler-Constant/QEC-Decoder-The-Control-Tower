"""Reproduce the selected decoder's submission from an explicit test CSV."""
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np,pandas as pd,stim
from decoder import decode,CONFIG,OUTPUT_MODE
parser=argparse.ArgumentParser()
parser.add_argument('--test',required=True,type=Path)
parser.add_argument('--output',default='submission_v2.csv',type=Path)
args=parser.parse_args(); root=Path(__file__).resolve().parent
frame=pd.read_csv(args.test)
assert frame.id.is_unique and frame.basis.isin(['X','Z']).all()
cols=[f'D{i}' for i in range(70)]; obs=[f'L{i}' for i in range(4)]
assert frame[cols].isin([0,1]).all().all()
answer=pd.DataFrame({'id':frame.id})
for col in obs: answer[col]=np.uint8(0)
meta={'decoder_sha256':hashlib.sha256((root/'decoder.py').read_bytes()).hexdigest(),'config':CONFIG,'output_mode':OUTPUT_MODE,'rows':len(frame),'basis_seconds':{}}
for basis in 'XZ':
 mask=frame.basis.eq(basis); events=frame.loc[mask,cols].to_numpy(dtype=np.uint8)
 circuit=stim.Circuit.from_file(str(root/f'{basis}_circuit.stim'))
 start=time.perf_counter(); predictions=decode(circuit,events); elapsed=time.perf_counter()-start
 assert predictions.shape==(len(events),4) and np.isin(predictions,[0,1]).all()
 # A reordered repeat must reproduce exactly the same predictions.
 repeated=decode(circuit,events[:32][::-1])[::-1]
 assert np.array_equal(repeated,predictions[:32])
 answer.loc[mask,obs]=predictions
 meta['basis_seconds'][basis]=elapsed
 print(basis,len(events),'shots;',round(elapsed,2),'seconds; repeat check passed',flush=True)
assert answer.id.equals(frame.id) and list(answer.columns)==['id',*obs]
assert answer[obs].isin([0,1]).all().all()
args.output.parent.mkdir(parents=True,exist_ok=True)
answer.to_csv(args.output,index=False)
meta['sha256']=hashlib.sha256(args.output.read_bytes()).hexdigest()
args.output.with_suffix('.metadata.json').write_text(json.dumps(meta,indent=2))
print('VERIFIED',str(args.output),answer.shape,flush=True)
