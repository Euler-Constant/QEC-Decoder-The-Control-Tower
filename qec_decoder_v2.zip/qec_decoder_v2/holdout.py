"""Independent holdout, seeds separate from tuning and previous validation."""
import json,time
from pathlib import Path
import numpy as np,stim
import baseline_decoder as base
from decoder import predict
root=Path(__file__).resolve().parent
N=10000; SEED=88023
configs=json.loads((root/'frozen_configs.json').read_text())
results=[]
for basis in 'XZ':
 c=stim.Circuit.from_file(str(root/f'{basis}_circuit.stim'))
 d,o=c.compile_detector_sampler(seed=SEED+ord(basis)).sample(N,separate_observables=True)
 start=time.perf_counter(); baseline=base.decode(c,d)
 row={'basis':basis,'config':'original','ler':float(np.mean(baseline!=o)),'seconds':time.perf_counter()-start,'shots':N}
 results.append(row); print(json.dumps(row),flush=True)
 for name,cfg in configs.items():
  start=time.perf_counter(); y,st=predict(c,d,**cfg); elapsed=time.perf_counter()-start
  for mode in [0,1]:
   delta=((baseline!=o).sum(axis=1)-(y[:,mode]!=o).sum(axis=1))/4
   row={'basis':basis,'config':name,'mode':['map','marginal'][mode],'ler':float(np.mean(y[:,mode]!=o)),'seconds':elapsed,'shots':N,'fixed_shots':int((st[:,0]>0).sum()),'fixed_mean':float(st[:,0].mean()),'fallback_shots':int(st[:,1].sum()),'invalid_shots':int(st[:,2].sum()),'improvement':float(delta.mean()),'paired_se':float(delta.std(ddof=1)/np.sqrt(N))}
   results.append(row); print(json.dumps(row),flush=True)
  np.savez_compressed(root/f'holdout_{basis}_{name}.npz',events=d,truth=o,predictions=y,stats=st,baseline=baseline)
 (root/'holdout_results.json').write_text(json.dumps(results,indent=2))
