"""Small exact problems verify the search and partial-correction bookkeeping."""
import itertools
from pathlib import Path
import numpy as np
from decoder import search, consistent, predict, decode
import stim
H=np.array([[1,0,0,1,1],[0,1,0,1,0],[0,0,1,0,1]],dtype=np.uint8)
L=np.array([[1,0,1,0,0],[0,1,0,0,1],[0,0,0,1,0],[1,0,0,0,1]],dtype=np.uint8)
p=np.array([.11,.07,.16,.09,.04]); prior=np.log((1-p)/p)
all_e=np.array(list(itertools.product((0,1),repeat=5)),dtype=np.uint8)
for syndrome in itertools.product((0,1),repeat=3):
 s=np.array(syndrome,np.uint8)
 feasible=all_e[np.all((all_e@H.T)%2==s,axis=1)]
 costs=feasible@prior
 best,mass,ok=search(H,L,s,prior,prior,np.zeros(5,np.uint8),5,5)
 assert ok and consistent(H,best,s)
 assert abs(best@prior-costs.min())<1e-10
 exact=np.zeros(16)
 for e,cost in zip(feasible,costs):
  bits=(L@e)%2; label=sum(int(b)<<i for i,b in enumerate(bits))
  exact[label]+=np.exp(-cost)
 assert np.allclose(mass/mass.sum(),exact/exact.sum())
# The same nonzero syndrome can represent different logical outcomes.
s=np.array([1,0,0],np.uint8)
f=all_e[np.all((all_e@H.T)%2==s,axis=1)]
assert len(np.unique((f@L.T)%2,axis=0))>1
# Bookkeeping: tentative correction plus residual correction reproduces D.
for e in all_e:
 fixed=np.array([e[0],0,0,0,0],np.uint8)
 original=(H@e)%2; residual=original^((H@fixed)%2)
 assert np.array_equal((H@(e^fixed))%2,residual)
 assert np.array_equal((L@e)%2,((L@fixed)%2)^((L@(e^fixed))%2))
print('PASS: exact MAP, exact candidate probability sums, logical ambiguity, residual XOR bookkeeping')
# Repeated and permuted calls must agree, for both circuit families.
for basis in 'XZ':
 c=stim.Circuit.from_file(str(Path(__file__).with_name(f'{basis}_circuit.stim')))
 d,_=c.compile_detector_sampler(seed=91).sample(20,separate_observables=True)
 a,st=predict(c,d,front_steps=6,threshold=3.)
 b,st2=predict(c,d[::-1],front_steps=6,threshold=3.)
 assert np.array_equal(a,b[::-1]) and np.array_equal(st,st2[::-1])
 assert st[:,2].sum()==0 and np.isin(a,[0,1]).all()
 selected=decode(c,d)
 assert selected.shape==(len(d),4) and np.isin(selected,[0,1]).all()
print('PASS: deterministic reordered shots and valid combined corrections for X/Z')
