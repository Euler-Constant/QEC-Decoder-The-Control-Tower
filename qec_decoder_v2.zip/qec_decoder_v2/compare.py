import json,time,sys
from pathlib import Path
import numpy as np,stim
import baseline_decoder as base
from decoder import predict
root=Path(__file__).resolve().parent
N=int(sys.argv[1]) if len(sys.argv)>1 else 3000
seed=int(sys.argv[2]) if len(sys.argv)>2 else 19031
results=[]
configs=[('strong',{}),('cascade99',{'front_steps':6,'threshold':4.6}),('cascade95',{'front_steps':6,'threshold':3.0})]
for basis in 'XZ':
 c=stim.Circuit.from_file(str(root/f'{basis}_circuit.stim'))
 d,o=c.compile_detector_sampler(seed=seed+ord(basis)).sample(N,separate_observables=True)
 start=time.perf_counter(); baseline=base.decode(c,d)
 entry={'basis':basis,'config':'baseline','ler':float(np.mean(baseline!=o)),'seconds':time.perf_counter()-start}
 results.append(entry); print(json.dumps(entry),flush=True)
 for name,config in configs:
  start=time.perf_counter(); y,st=predict(c,d,**config)
  for mode in [0,1]:
   wrong=(y[:,mode]!=o).sum(axis=1); before=(baseline!=o).sum(axis=1)
   entry={'basis':basis,'config':name,'mode':['map','marginal'][mode],'ler':float(wrong.mean()/4),'seconds':time.perf_counter()-start,'fixed_mean':float(st[:,0].mean()),'fixed_shots':int((st[:,0]>0).sum()),'fallback_shots':int(st[:,1].sum()),'invalid_shots':int(st[:,2].sum()),'paired_improvement':float((before-wrong).mean()/4),'paired_se':float((before-wrong).std(ddof=1)/4/np.sqrt(N))}
   results.append(entry); print(json.dumps(entry),flush=True)
  np.savez_compressed(root/f'tune_{basis}_{name}.npz',events=d,truth=o,predictions=y,stats=st,baseline=baseline)
 (root/f'comparison_{N}_{seed}.json').write_text(json.dumps(results,indent=2))
